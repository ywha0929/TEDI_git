#include <iostream>

using namespace std;

int main(void) {
    string a;
    cin >> a;
    cout << "\"" + a + "\"" << endl;
    return 0;
}