#include <iostream>

using namespace std;

int main(void) {
    int n;
    int arr[50];
    cin >> n;

    for(int i = 0; i < n; i++) {
        cin >> arr[i];
    }
    for(int i = 0; i < @@@; i++) {
        cout << @@@ << endl;
    }
    return 0;
}