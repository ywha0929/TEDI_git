#include <iostream>
#include <string>

using namespace std;

int main(void) {
    string n;
    cin >> n;
    for(int i = @@@; i > @@@; i--) {
        cout << n[i];
    }
    return 0;
}