#include <iostream>

using namespace std;

int main(void) {
    int n;
    cin >> n;
    
    int i = 1;
    while(@@@) {
        cout << i << endl;
        i@@@;
    }
    return 0;
}