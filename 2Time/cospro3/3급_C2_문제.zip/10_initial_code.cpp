#include <iostream>

using namespace std;

int main(void) {
    // 여기에 코드를 작성해주세요. 아래 주석은 예시입니다.
    // int a;
    // cin >> a;
    // cout << a << endl;
    return 0;
}